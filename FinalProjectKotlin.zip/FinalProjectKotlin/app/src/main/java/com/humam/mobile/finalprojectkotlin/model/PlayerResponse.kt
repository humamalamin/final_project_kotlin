package com.humam.mobile.finalprojectkotlin.model

data class PlayerResponse(val player: MutableList<PlayerItem>) {
}