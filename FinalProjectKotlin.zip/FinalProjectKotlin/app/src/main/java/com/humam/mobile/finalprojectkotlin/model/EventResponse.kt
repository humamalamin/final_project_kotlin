package com.humam.mobile.finalprojectkotlin.model

data class EventResponse(val events: MutableList<EventsItem>) {
}