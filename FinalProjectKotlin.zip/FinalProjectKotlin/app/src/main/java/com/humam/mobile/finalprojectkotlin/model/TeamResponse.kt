package com.humam.mobile.finalprojectkotlin.model

data class TeamResponse(val teams: MutableList<TeamsItem>) {
}