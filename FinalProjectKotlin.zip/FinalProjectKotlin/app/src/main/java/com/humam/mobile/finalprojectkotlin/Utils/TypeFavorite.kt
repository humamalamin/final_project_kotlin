package com.humam.mobile.finalprojectkotlin.Utils

enum class TypeFavorite {
    MATCHES, TEAMS
}