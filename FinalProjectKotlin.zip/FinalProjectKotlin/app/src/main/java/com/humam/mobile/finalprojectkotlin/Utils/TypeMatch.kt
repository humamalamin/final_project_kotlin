package com.humam.mobile.finalprojectkotlin.Utils

enum class TypeMatch {
    NEXT, LAST
}